from distutils.core import setup
setup(name = "xsp", 
	version = "0.3", 
	py_modules = ["xsp"],
	author = "Nick Saika",
	author_email = "nicksaika@gmail.com")
