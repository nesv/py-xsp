from distutils.core import setup
setup(name = "xsp", 
	version = "0.2", 
	py_modules = ["xsp"],
	author = "Nick Saika",
	author_email = "nicksaika@gmail.com")
